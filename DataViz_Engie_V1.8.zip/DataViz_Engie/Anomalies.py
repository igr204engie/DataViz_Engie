import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output,State
import plotly.graph_objs as go
import initialisation as init
import pandas as pd
import numpy as np
import datetime
import calendar
import visdcc
import json
import locale
locale.setlocale(locale.LC_ALL,'')

#Constantes
NORMAL_DAY = 'CornflowerBlue'

# Initialisation
df_all_feat = init.get_all_features()
df_ano = init.get_anomalies()
df_res = init.get_res()
df_res_cum = init.get_res_cum()
df_res_clustering = init.get_clustering()
df_clust_kmeans2 = init.get_kmeans2()
Z = init.get_contour()
color=init.gen_color()

dict_color_ano = {'Déconnexion' : 'DimGray',
                  'Retard prod.': 'black',
                  'Sans valeur':'rgba(128,0,128,1)',
                  'Sous-perf. courte':'fuchsia',
                  'Sous-perf. longue' : 'rgba(255,0,0,1)'}

# On prépare les dict des étiquettes et valeur du range slider
#min_date = df_all_feat["2017-06-01":].index.date.min()
min_date = datetime.datetime.strptime("2017-06-01", "%Y-%m-%d") 
datelist=pd.date_range(min_date, periods=19, freq='MS')

mark_month={} # dict des markers de mois abrégés "Apr', "May', etc
date_values={} #dict des valeurs correspondantes aux markers
m=1
for i in datelist:
    if i.year==2017 and i.month==6:
        mark_month[m] = {'label':i.strftime('%b') + " 2017",  'style': {'z-index': '5'} }
    elif i.year==2018 and i.month==1:
        mark_month[m] = {'label':i.strftime('%b') + " 2018",  'style': {'z-index': '5'} }
    else:
        mark_month[m] = {'label':i.strftime('%b'),  'style': {'z-index': '5'} }
    date_values[m]=str(i.year)+"-"+str(i.month)
    m+=1

# On enregistre les cliques sur les graphes pour la mise à jour du graph par jour
# current_day : jour courant du graphique de production jour
# day1_clicked : valeur du clique sur le graphique du clustering
# day2_clicked : valeur du clique sur le graphique global
current_day = None
day1_clicked = None
day2_clicked = None
    
def getAnomaliesGlobal():
    return html.Div([

        html.Div([
                dcc.RangeSlider(
                    id="slider-anomalies",
                    min=1,
                    max=19,
                    value=[15,18],
                    marks=mark_month,
                    pushable=3,
                    #disabled=True
                )], style={'width':'95%', 'display': 'inline-block',"top":"-45px","position":"absolute"}),
        
        html.Div([
                   dcc.RadioItems(
                        id="rbl_type_seuil",
                        options=[
                            {'label': 'Seuil fixe', 'value': 'Res_neg'},
                            {'label': 'Seuil %', 'value': 'Percent'},
                            {'label': 'DTW', 'value': 'DTW'}],
                        value='Res_neg',
                        labelStyle={'position':'relative', 'padding-right':'10px', 'z-index':'10', 'float': 'right'}
                    )], style={'position':'relative', 'top':'50px'}),
        
        html.Div([dcc.Graph(id='graph-Anomalies-Global')], )
    ], style={'width': '95%'})
    
def getAnomaliesPerType():
 
    return html.Div([

              html.Div([ dcc.Graph(id='graph-Anomalies-Per-Type')], )
           ], style={'width':'95%'})

def getAnomaliesDay():
    
    return html.Div([
     
        html.Div([
                   dcc.Checklist(
                           id="chk_irr_ano",
                           options=[{'label': "Ref. Irr", 'value': 'REF_IRR'}],
                           values=['REF_IRR'],
                           labelStyle={'position':'relative', 'z-index':'10', 'float': 'right'}
                )], style={'width':'95%'}),
        
        html.Div([ dcc.Graph(id='graph-Anomaly-Day', ),]),
        
    ], style={'width':'95%'})

def getClusteringDay():
    return html.Div([
              dcc.Graph(id='graph-Anomalies-clustering'),
              html.Div([
                    dcc.RadioItems(
                            id="rbl_clustering_algo",
                            options=[
                                {'label': ' Isol. Forest', 'value': 'Isolation_Forest'},
                                {'label': ' Robust Cov.', 'value': 'Robust_covariance'}],
                            value='Isolation_Forest',
                            labelStyle={'position':'relative','padding-right':'10px', 
                                        'z-index':'10', 'float': 'left', 'font-size':'12px'}
                            ),
                
                    dcc.Checklist(
                            id="chk_kmeans",
                            options=[{'label': ' K-means', 'value': 'kmeans'}],
                            values=[''],
                            labelStyle={'position':'relative', 'z-index':'10', 'float': 'left', 'font-size':'12px'}
                        ),  
                  
              ], style={'position':'relative', 'display':'inline-block',
                                'valign':'top','top':"-41vh","left":"27vw", 'width':'100px'}),
                
             
         ])


def anomalies_callbacks(app,carte_coords):
   
    @app.callback(
        Output('graph-Anomalies-Global', 'figure'),
        [Input('data_points', 'children'),
        Input('rbl_type_seuil', 'value')])
    def update_graph_Anomalies_Global(list_inv_selected, type_seuil):
        data=json.loads(list_inv_selected)
        list_inv_raw=json.loads(data['onduleur'])
        list_inv = [inv for inv in list_inv_raw if list_inv_raw[inv] == 1]
        sel_ond = list_inv[0]
        sel_ond_court = sel_ond.replace("PVT0", "").replace("INV0", "")
        my_blue = NORMAL_DAY
        
        idx = pd.IndexSlice
        df_res_cum_1 = df_res_cum.copy()
        df_res_one_inv = df_res_cum_1.loc[:, idx[[sel_ond], ["Res_neg", "Manu", "Percent", "DTW", "Type"]]]
        #df_res_one_inv.columns = df_res_one_inv.columns.to_flat_index()
        df_res_one_inv.columns = ["Res_neg", "DTW", "Percent", "Manu", "Type"]
        df_ano_temp = df_res_one_inv[df_res_one_inv["Manu"] == 1]

        # Set date limits for X axis
        date_min = df_res_one_inv.index[0].strftime("%Y-%m-%d")
        date_max = df_res_one_inv.index[-1].strftime("%Y-%m-%d")
        line_date_min = df_res_one_inv.index[0] - datetime.timedelta(days=4)
        line_date_max = df_res_one_inv.index[-1] + datetime.timedelta(days=4)
        
        if type_seuil=="Res_neg":
            threshold_detect = 2650
            df_ano_threshold = df_res_one_inv[df_res_one_inv[type_seuil]<=-threshold_detect]
        elif type_seuil=="Percent":
            threshold_detect = 4.2
            df_ano_threshold = df_res_one_inv[df_res_one_inv[type_seuil]>=threshold_detect]
        else:
            #DTW
            threshold_detect = 240
            df_ano_threshold = df_res_one_inv[df_res_one_inv[type_seuil]>=threshold_detect]
        
        TruePositive = int(df_ano_threshold["Manu"].sum())
        FalsePositive = len(df_ano_threshold) - TruePositive
        FalseNegative = int(df_res_one_inv["Manu"].sum()) - TruePositive
        TrueNegative = len(df_res_one_inv) - len(df_ano_threshold) - FalseNegative
        
        #Precision / Recall / F1
        if len(df_ano_threshold)!=0:
            Precision = TruePositive / len(df_ano_threshold)
        else:
            Precision = 0
        if len(df_ano_temp)!=0:
            Recall = TruePositive / len(df_ano_temp)
        else:
            Recall = 0
        if Precision!=0 or Recall!=0:
            F1_score = 2 * (Precision * Recall) / (Precision + Recall)
        else:
            F1_score = 0
            
        #print("Precision : {:0.2f} - Rappel : {:0.2f} - F1 : {:0.2f}".format(Precision, Recall, F1_score))
        ##Confusion Matrix
        #print("Confusion Matrix")
        #print("{:3d} | {:3d}".format(TruePositive, FalsePositive))
        #print("{:3d} | {:3d}".format(FalseNegative, TrueNegative))

        # Graph initialization
        list_data = []

        # Plot the day lines
        bar_data = go.Bar(
                        x = df_res_one_inv[date_min:date_max].index,
                        y = abs(df_res_one_inv[date_min:date_max][type_seuil]),
                        name=sel_ond_court,
                        marker = dict(color=my_blue)
                     )
        list_data.append(bar_data)

        # Plot the normal day points
        res_sum_plot = go.Scatter(
            x=df_res_one_inv[date_min:date_max].index,
            y=abs(df_res_one_inv[date_min:date_max][type_seuil]),
            # text = day,
            name='Normal',
            mode='markers',
            marker=dict(size=8,color=my_blue)
        )
        list_data.append(res_sum_plot)

        # Plot the anomaly day points
        for ano_type in df_ano_temp[date_min:date_max]["Type"].unique():
            df_ano_type = df_ano_temp[date_min:date_max][df_ano_temp["Type"]==ano_type]
            res_sum_man = go.Scatter(
                x=df_ano_type.index,
                y=abs(df_ano_type[type_seuil]),
                text = ano_type,
                name = ano_type,
                mode='markers',
                marker=dict(size=8, color=dict_color_ano[ano_type])
            )
            list_data.append(res_sum_man)

        return {
            'data': list_data,
            'layout': go.Layout(
                title = "<b>" + sel_ond_court + "&nbsp;</b>- Somme des résidus / jour" 
                        + " - <b>F1</b> = <b>" + str(round(F1_score,2)) + "</b> avec seuil à " + str(threshold_detect)
                        + " (" + str(TruePositive) + "/" + str(len(df_ano_temp)) +")" ,
                titlefont={'size':14},
                # Horizontal Line
                shapes = [
                {
                    'type': 'line',
                    'x0': line_date_min,
                    'y0': abs(threshold_detect),
                    'x1': line_date_max,
                    'y1': abs(threshold_detect),
                    'line': {
                        'color': 'dimGray',
                        'width': 2,
                        'dash': 'dot'
                    },
                }],
                yaxis={'title': 'Somme des résidus'},
                showlegend=True,
                legend=go.layout.Legend(
                    x=0,
                    y=1.1,
                    orientation="h",
                    font={'size': 10}),
                width=1000,
                height=350,
                margin={'l': 70, 'b': 70, 't': 70, 'r': 0, 'pad': 0},
                bargap=0.9,
                hovermode='closest',
                clickmode='event'
            )
        }


    @app.callback(
    Output('graph-Anomalies-Per-Type', 'figure'),
    [Input('slider-global', 'value'),
     Input('data_points', 'children')])
    def update_graph_Anomalies_Per_Type(range_date, list_inv_selected):
        
        data=json.loads(list_inv_selected)
        list_inv_raw=json.loads(data['onduleur'])
        list_inv = [inv for inv in list_inv_raw if list_inv_raw[inv]==1]
        list_inv.sort()
        #print(list_inv)
        
        list_inv_axis = [inv.replace("PVT0","").replace("INV0","") for inv in list_inv]
                        
        df_ano_1 = df_ano.copy()
        df_ano_1 = df_ano_1[df_ano_1['Ano']==1]
        
        #On fixe ces dates tant qu'on n'a pas de prédictions sur l'ensemble de la période
        #date_min = date_values[range_date[0]]
        #date_max = date_values[range_date[1]]
        
        date_min = date_values[15]
        date_max = date_values[19]
        
        title_first_month = datetime.datetime.strftime(datetime.datetime.strptime(date_min, "%Y-%m"), "%b %y")
        title_last_month = datetime.datetime.strftime(datetime.datetime.strptime(date_max, "%Y-%m"), "%b %y")
        
        df_bars = df_ano_1[date_min:date_max].groupby(by='Type').sum()
        df_bars["Type_Temp"] = df_bars.index
        df_bars["Couleur"] = df_bars["Type_Temp"].apply(lambda x : dict_color_ano[x])
        
        data = go.Bar(
                        x = df_bars.index, 
                        y = df_bars[list_inv_axis[0]],
                        marker=dict(color=df_bars["Couleur"]),
                        #marker=dict(color=list(dict_color_ano.values()))
                     )

        return {
            'data': [data],
            'layout': go.Layout(
                title="<b>" + list_inv_axis[0] + "</b>" + ": NB anomalies de <b>" + title_first_month  + "</b> à <b>" + title_last_month + "</b>" ,
                titlefont={'size':14},
                xaxis={
                        'tickangle':30,
                        'tickfont': {'size':12.2, 'color':'black'}
                      },
                showlegend=False,
                width=350,
                height=370,
                margin={'l': 50, 'b': 70, 't': 30, 'r': 60, 'pad':10},
                hovermode='closest'
                )
        }
    
    @app.callback(
    Output('graph-Anomaly-Day', 'figure'),
    [Input('graph-Anomalies-clustering', 'clickData'),
     Input('graph-Anomalies-Global', 'clickData'),
     Input('chk_irr_ano', 'values'),
     Input('data_points', 'children')])
    def update_graph_day(cluster_selected, residu_selected, disp_irr, list_inv_selected):

        global day1_clicked
        global day2_clicked
        global current_day
        
        data=json.loads(list_inv_selected)
        list_inv_raw=json.loads(data['onduleur'])
        list_inv = [inv for inv in list_inv_raw if list_inv_raw[inv]==1]
        sel_ond = list_inv[0]
        sel_ond_court = sel_ond.replace("PVT0", "").replace("INV0", "")
        
        idx = pd.IndexSlice
        df_res_one_inv = df_res.loc[:, idx[sel_ond, [sel_ond, "Pred","Res", "GT_IRR"]]]

        if cluster_selected is None and residu_selected is None:
            # premier affichage du graph
            date = "2018-08-01"
            title_date = "1 Aug"
            current_day = date
        else:
            # L'utilitsateur a cliqué sur un des deux graphiques, lequel ?
            if residu_selected is None:
                # Le clique a eu lieu sur le graphique cluster et aucun clique n'a jamais été fait sur les résidus
                date = cluster_selected["points"][0]['text'][:10]
                current_day = date
                day1_clicked = date
            elif cluster_selected is None:
                # Le clique a eu lieu sur le graphique résidus et aucun clique n'a jamais été fait sur le cluster
                date = residu_selected["points"][0]['x'][:10]
                current_day = date
                day2_clicked = date
            else:
                # Les deux graphes ont été cliqués, mais il faut savoir quelle est la date
                # à prendre en compte, car les valeurs de clickData sont persistentes...
                date1 = cluster_selected["points"][0]['text'][:10]
                date2 = residu_selected["points"][0]['x'][:10]
                
                if date1!=date2:
                    #Il y a une différence entre les valeurs des jours cliqués entre les deux graphes
                    if date1 != day1_clicked:
                        #la valeur du clique sur le graphique cluster a changé, elle provient de là
                        date = date1
                        current_day = date
                        day1_clicked = date
                    else:
                        # la valeur du clique sur le graphique cluster n'a pas changé
                        if date2 != day2_clicked:
                            # la valeur du clique sur le graphique résidu a changé, le clique provient de là
                            date = date2
                            current_day = date
                            day2_clicked = date
                        else:
                            # ni la valeur du clique sur le graphe cluster, ni celle sur le graph résidu n'ont changé
                            # il y a donc eu un clique sur le même point sur l'un des deux graphiques, lequel ?
                            if date1==current_day:
                                # Le clique a eu lieu sur le graphique semaine
                                date = date1
                            else:
                                # Le clique a eu lieu sur le graphique global
                                date = date2
                else:
                    #les deux dates coïncident, elles étaient peut-être différentes avant
                    #On met à jour tout le monde à la même date
                    date = date1
                    current_day = date
                    day1_clicked = date
                    day2_clicked = date
        
        title_date = datetime.datetime.strftime(datetime.datetime.strptime(date, "%Y-%m-%d"), "%d %b %Y")
        list_data = []

        prod_data = go.Scatter(
                            x = df_res_one_inv[date+" 04":date+" 19"].index,
                            y = df_res_one_inv[date+" 04":date+" 19"].loc[:, idx[sel_ond, sel_ond]], 
                            #text = day,
                            name = sel_ond,
                            mode ='lines',
                            line = dict(width = 2, color=(color[sel_ond])),
                            #marker = dict(size = 3)
                         )
        list_data.append(prod_data)
        
        pred_data = go.Scatter(
                            x = df_res_one_inv[date+" 04":date+" 19"].index,
                            y = df_res_one_inv[date+" 04":date+" 19"].loc[:, idx[sel_ond, "Pred"]],
                            #text = day,
                            name = "Prediction",
                            mode ='lines',
                            line = dict(width = 2, dash = "dot", color=(color[sel_ond])),
                            #marker = dict(size = 3)
                         )
        list_data.append(pred_data)

        res_data = go.Scatter(
                            x = df_res_one_inv[date+" 04":date+" 19"].index,
                            y = df_res_one_inv[date+" 04":date+" 19"].loc[:, idx[sel_ond, "Res"]], 
                            #text = day,
                            name = "Résidu",
                            mode ='lines',
                            line = dict(width = 2, color=("black")),
                         )
        list_data.append(res_data)
        
        Irrad = go.Scatter(
                            x = df_res_one_inv[date+" 04":date+" 19"].index,
                            y = df_res_one_inv[date+" 04":date+" 19"].loc[:, idx[sel_ond, "GT_IRR"]], 
                            #text = day,
                            name = "GT. Irradiance",
                            mode = 'lines',
                            line = dict(color = ('rgb(227,26,28)'), width = 3)
                            )

        if disp_irr.count('REF_IRR')!=0 : list_data.append(Irrad)

        return {
            'data': list_data,
            'layout': go.Layout(
                title="Production du <b>" + title_date  + "</b>" ,
                titlefont={'size':14},
                yaxis={'title': 'Puissance (kWh)', 'rangemode':'tozero'},
                showlegend=True,
                width=500,
                height=370,
                margin={'l': 70, 'b': 30, 't': 30, 'r': 0, 'pad':10},
                hovermode='closest'
                )
        }
    
    @app.callback(
     Output('graph-Anomalies-clustering', 'figure'),
    [Input('slider-global', 'value'),
     Input('data_points','children'),
     Input('rbl_clustering_algo', 'value'),
     Input('chk_kmeans','values')])
    def update_graph_Anomalies_clustering(range_date, list_inv_selected, algo, disp_kmeans):
        data=json.loads(list_inv_selected)
        list_inv_raw=json.loads(data['onduleur'])
        list_inv = [inv for inv in list_inv_raw if list_inv_raw[inv]==1]
        inverter = list_inv[0]
        graph_clust_data = []
        df_res_clustering2 = df_res_clustering.loc[:,inverter]
        df = df_clust_kmeans2.loc[:,inverter]
        
        if (algo !='kmeans'):
            f = str(inverter) + algo
            Zc = Z[f]
        
        #residu_tp = df[df.Confusion=='TruePositive']
        residu_tp = df[(df.anomalie==1) & (df.Manu==1)]
        df_res_anomalie = df_res_clustering2[df_res_clustering2.Manu==1]
        df_res_normal = df_res_clustering2[df_res_clustering2.Manu==0]
        
        r = np.concatenate((df_res_anomalie.X,df_res_normal.X))
        ry = np.concatenate((df_res_anomalie.Y,df_res_normal.Y))
        x_min, x_max = np.min(r) - 100, np.max(r) + 100
        y_min, y_max = np.min(ry) - 100, np.max(ry) + 100

        xx = np.linspace(x_min, x_max, 800)
        yy = np.linspace(y_min, y_max, 800)
        
        #Calul du F1 score Isolation
        TruePositive_algo = len(df_res_clustering2[(df_res_clustering2.Manu==1) & (df_res_clustering2[algo]==1)])
        FalsePositive_algo = len(df_res_clustering2[(df_res_clustering2.Manu==0) & (df_res_clustering2[algo]==1)])
        FalseNegative_algo = len(df_res_clustering2[(df_res_clustering2.Manu==1) & (df_res_clustering2[algo]==0)])
        TrueNegative_algo = len(df_res_clustering2[(df_res_clustering2.Manu==0) & (df_res_clustering2[algo]==0)])
        #
        ##Precision / Recall / F1
        if (TruePositive_algo + FalsePositive_algo)!=0:
            Precision_algo = TruePositive_algo / (TruePositive_algo + FalsePositive_algo)
        else:
            Precision_algo = 0
            
        if len(df[df.Manu==1])!=0:
            Recall_algo = TruePositive_algo / len(df_res_clustering2[df_res_clustering2.Manu==1])
        else:
            Recall_algo = 0
        if Precision_algo!=0 or Recall_isolation!=0:
            F1_score_algo = 2 * (Precision_algo * Recall_algo) / (Precision_algo + Recall_algo)
        else:
            F1_score_algo = 0
        
        #print("Precision isolation : {:0.2f} - Rappel : {:0.2f} - F1 : {:0.2f}".format(Precision_algo, Recall_algo, F1_score_algo))
        #Confusion Matrix
        #print("Confusion Matrix")
        #print("{:3d} | {:3d}".format(TruePositive_algo, FalsePositive_algo))
        #print("{:3d} | {:3d}".format(FalseNegative_algo, TrueNegative_algo))
        
        #Calul du F1 score k-means
        TruePositive_kmeans = len(residu_tp)
        FalsePositive_kmeans = len(df[(df.anomalie==1) & (df.Manu==0)])
        FalseNegative_kmeans = len(df[(df.anomalie==0) & (df.Manu==1)])
        TrueNegative_kmeans = len(df[(df.anomalie==0) & (df.Manu==0)])
        #
        ##Precision / Recall / F1
        if (TruePositive_kmeans + FalsePositive_kmeans)!=0:
            Precision_kmeans = TruePositive_kmeans / (TruePositive_kmeans + FalsePositive_kmeans)
        else:
            Precision_kmeans = 0
            
        if len(df[df.Manu==1])!=0:
            Recall_kmeans = TruePositive_kmeans / len(df[df.Manu==1])
        else:
            Recall_kmeans = 0
        if Precision_kmeans!=0 or Recall_kmeans!=0:
            F1_score_kmeans = 2 * (Precision_kmeans * Recall_kmeans) / (Precision_kmeans + Recall_kmeans)
        else:
            F1_score_kmeans = 0
        
        #print("Precision k-means : {:0.2f} - Rappel : {:0.2f} - F1 : {:0.2f}".format(Precision_kmeans, Recall_kmeans, F1_score_kmeans))
        #Confusion Matrix
        #print("Confusion Matrix")
        #print("{:3d} | {:3d}".format(TruePositive_kmeans, FalsePositive_kmeans))
        #print("{:3d} | {:3d}".format(FalseNegative_kmeans, TrueNegative_kmeans))
        
        
        clust2 = go.Scatter(
                name="Normal",
                text=df_res_normal.index,
                x = df_res_normal.X, 
                y = df_res_normal.Y,
                hoverinfo = 'text',
                mode = 'markers',
                marker = dict(size = 8,color=(NORMAL_DAY))
                )
        
        kmeans3 = go.Scatter(
                name="Anomalies kmeans",
                text=residu_tp.index,
                x = residu_tp.X, 
                y = residu_tp.Y,
                hoverinfo = 'text',
                mode = 'markers',
                marker= {'color': 'white', 'size': 4,
                         'line' : {'width' : 1, 'color' : 'rgb(200, 200, 200)'}
                        }
                )
        
        cont = go.Contour(
              x= xx,
              y = yy,
              z = np.array(Zc),
              #type = 'contour',
              hoverinfo = 'skip',
              showscale = False,
              colorscale =[[0,"white"],[1,"rgba(245,245,245,1)"]]
              )

        graph_clust_data.append(cont)
        
        # On ajoute les points d'anomalie après le contour sinon le hover n'apparait pas !
        for ano_type in df_res_anomalie["Type"].unique():
            df_ano_type = df_res_anomalie[df_res_anomalie["Type"]==ano_type]
            clust1 = go.Scatter(
                name = ano_type,
                text = df_ano_type.index.astype(str)+ "<br>" + ano_type,
                x = df_ano_type.X,
                y = df_ano_type.Y,

                mode = 'markers',
                hoverinfo = 'text',
                marker=dict(size=8, color=dict_color_ano[ano_type])
            )
            graph_clust_data.append(clust1)
            
        graph_clust_data.append(clust2)
        
        str_F1_kmeans = ""
        if disp_kmeans.count('kmeans')!=0: 
            graph_clust_data.append(kmeans3)
            str_F1_kmeans = " (k-means : " + str(round(F1_score_kmeans,2)) +")"
        
        return {
          'data': graph_clust_data,
          'layout': go.Layout(
            title= "PCA résidus + <b>"+ algo + "</b> - <b>F1</b> : <b>" + str(round(F1_score_algo,2)) +"</b>" + str_F1_kmeans,
                    titlefont={'size':14},
                    showlegend=True,
                    legend = dict(orientation='h', x=0, y=1, font={'size': 10}),
                    xaxis = dict(
                        showgrid=True,
                        zeroline=False,
                        showline=True,
                    ),
                    yaxis = dict(
                        showgrid=True,
                        zeroline=False,
                        showline=False,
                    ),
                    width=500,
                    height=420,
                    margin={'l': 70, 'b': 80, 't': 30, 'r': 0, 'pad':0},
                    hovermode='closest'
        
                )

        }