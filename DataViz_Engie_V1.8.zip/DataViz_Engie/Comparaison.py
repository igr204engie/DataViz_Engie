import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output,State
import plotly.graph_objs as go
import initialisation as init
import pandas as pd
import datetime
import calendar
import visdcc
import json
import locale
locale.setlocale(locale.LC_ALL,'')

df_all_feat = init.get_all_features()

color=init.gen_color()

# On prépare les dict des étiquettes et valeur du range slider
#min_date = df_all_feat["2017-06-01":].index.date.min()
min_date = datetime.datetime.strptime("2017-06-01", "%Y-%m-%d") 
datelist=pd.date_range(min_date, periods=19, freq='MS')

mark_month={} # dict des markers de mois abrégés "Apr', "May', etc
date_values={} #dict des valeurs correspondantes aux markers
m=1
for i in datelist:
    if i.year==2017 and i.month==6:
        mark_month[m] = {'label':i.strftime('%b') + " 2017",  'style': {'z-index': '5'} }
    elif i.year==2018 and i.month==1:
        mark_month[m] = {'label':i.strftime('%b') + " 2018",  'style': {'z-index': '5'} }
    else:
        mark_month[m] = {'label':i.strftime('%b'),  'style': {'z-index': '5'} }
    date_values[m]=str(i.year)+"-"+str(i.month)
    m+=1

# On enregistre les cliques sur les graphes pour la mise à jour du graph par jour
# current_day : jour courant du graphique de production jour
# day1_clicked : valeur du clique sur le graphique du détail à la semaine
# day2_clicked : valeur du clique sur le graphique global
current_day = None
day1_clicked = None
day2_clicked = None

def getComparaisonGlobal():

    return html.Div([html.Div(children=[

        dcc.RangeSlider(
            id="slider-global",
            min=1,
            max=19,
            value=[1,19],
            marks=mark_month,
            pushable=3
        )], style={'width':'95%', 'display': 'inline-block',"top":"-45px","position":"absolute"}),

        html.Div(className="",style={'height':'45vh'},children=[dcc.Graph(id='graph-Comparison-All-Weeks')])
    ])





def getComparaisonWeek():
 
    return html.Div([

              html.Div([ dcc.Graph(id='graph-Comparison-Week')], )
           ], style={'width':'95%'})

def getComparaisonTotalProduction():
 
    return html.Div([

              html.Div([ dcc.Graph(id='graph-Comparison-Total-Production')], )
           ], style={'width':'95%'})

def getComparaisonDay():
    
    return html.Div([
     
        html.Div([
                   dcc.Checklist(
                           id="chk_irr",
                           options=[{'label': "Ref. Irr", 'value': 'REF_IRR'}],
                           values=['REF_IRR'],
                           labelStyle={'position':'relative', 'z-index':'10', 'float': 'right'}
                )], style={'width':'95%'}),
        
        html.Div([ dcc.Graph(id='graph-Comparison-Day', ),]),
        
    ], style={'width':'95%'})


def comparaison_callbacks(app,carte_coords):
    @app.callback(
    Output('graph-Comparison-Day', 'figure'),
    [Input('graph-Comparison-Week', 'clickData'),
     Input('graph-Comparison-All-Weeks', 'clickData'),
     Input('chk_irr', 'values'),
     Input('data_points','children')])
    def update_graph_day(day_selected, week_selected, disp_irr, list_inv_selected):

        global day1_clicked
        global day2_clicked
        global current_day


        data=json.loads(list_inv_selected)
        list_inv_raw=json.loads(data['onduleur'])
        list_inv = [inv for inv in list_inv_raw if list_inv_raw[inv]==1]
        
        if day_selected is None and week_selected is None:
            # premier affichage du graph
            date = "2017-06-01"
            title_date = "1 Juin"
            current_day = date
        else:
            # L'utilitsateur a cliqué sur un des deux graphiques, lequel ?
            if week_selected is None:
                # Le clique a eu lieu sur le graphique semaine et aucun clique n'a jamais été fait sur le global
                date = day_selected["points"][0]['x'][:10]
                current_day = date
                day1_clicked = date
            elif day_selected is None:
                # Le clique a eu lieu sur le graphique global et aucun clique n'a jamais été fait sur le semaine
                date = week_selected["points"][0]['x'][:10]
                current_day = date
                day2_clicked = date
            else:
                # Les deux graphes ont été cliqués, mais il faut savoir quelle est la date
                # à prendre en compte, car les valeurs de clickData sont persistentes...
                date1 = day_selected["points"][0]['x'][:10]
                date2 = week_selected["points"][0]['x'][:10]
                
                if date1!=date2:
                    #Il y a une différence entre les valeurs des jours cliqués entre les deux graphes
                    if date1 != day1_clicked:
                        #la valeur du clique sur le graphique semaine a changé, elle provient de là
                        date = date1
                        current_day = date
                        day1_clicked = date
                    else:
                        # la valeur du clique sur le graphique semaine n'a pas changé
                        if date2 != day2_clicked:
                            # la valeur du clique sur le graphique global a changé, le clique provient de là
                            date = date2
                            current_day = date
                            day2_clicked = date
                        else:
                            # ni la valeur du clique sur le graphe semaine, ni celle sur le graph global n'ont changé
                            # il y a donc eu un clique sur le même point sur l'un des deux graphiques, lequel ?
                            if date1==current_day:
                                # Le clique a eu lieu sur le graphique semaine
                                date = date1
                            else:
                                # Le clique a eu lieu sur le graphique global
                                date = date2
                else:
                    #les deux dates coïncident, elles étaient peut-être différentes avant
                    #On met à jour tout le monde à la même date
                    date = date1
                    current_day = date
                    day1_clicked = date
                    day2_clicked = date
                    
        title_date = datetime.datetime.strftime(datetime.datetime.strptime(date, "%Y-%m-%d"), "%d %b %Y")
        list_data = []

        for inv in list_inv:
            temp_series = go.Scatter(
                                x = df_all_feat[date+" 04":date+" 19"].index,
                                y = df_all_feat[date+" 04":date+" 19"][inv],
                                #text = day,
                                name = inv,
                                mode ='lines',
                                line = dict(width = 2, color=(color[inv])),
                                #marker = dict(size = 3)
                             )
            list_data.append(temp_series)

        Irrad = go.Scatter(
                x = df_all_feat[date+" 04":date+" 19"].index,
                y = df_all_feat[date+" 04":date+" 19"]["REF_IRR"],
                #text = day,
                name = "Ref. Irradiance",
                mode = 'lines',
                line = dict(color = ('rgb(227,26,28)'), width = 3)
                )

        if disp_irr.count('REF_IRR')!=0 : list_data.append(Irrad)

        return {
            'data': list_data,
            'layout': go.Layout(
                title="Production du <b>" + title_date  + "</b>" ,
                titlefont={'size':14},
                yaxis={'title': 'Puissance (kWh)', 'rangemode':'tozero'},
                showlegend=False,
                width=500,
                height=370,
                margin={'l': 70, 'b': 30, 't': 30, 'r': 0, 'pad':10},
                hovermode='closest'
                )
        }
    
    @app.callback(
    Output('graph-Comparison-All-Weeks', 'figure'),
    [Input('slider-global', 'value'),
     Input('data_points','children')])
    def update_graph_All_Weeks(range_date, list_inv_selected):



        data=json.loads(list_inv_selected)
        list_inv_raw=json.loads(data['onduleur'])
        list_inv = [inv for inv in list_inv_raw if list_inv_raw[inv]==1]
        
        date_min = date_values[range_date[0]]
        date_max = date_values[range_date[1]]
        print(color)
        list_data = []

        for inv in list_inv:
            temp_series = go.Scatter(
                                x = df_all_feat[date_min:date_max].iloc[:,:8].resample("7D").sum().index,
                                y = df_all_feat[date_min:date_max].iloc[:,:8].resample("7D").sum()[inv],
                                #text = day,
                                name = inv,
                                mode ='lines+markers',
                                line = dict(width = 2, color=(color[inv])),
                                marker = dict(size = 5)
                             )
            list_data.append(temp_series)
        
        title_first_month = datetime.datetime.strftime(datetime.datetime.strptime(date_min, "%Y-%m"), "%b %y")
        title_last_month = datetime.datetime.strftime(datetime.datetime.strptime(date_max, "%Y-%m"), "%b %y")
            
        return {
            'data': list_data,
            'layout': go.Layout(#title="Séries onduleurs au " + date,
                title="Production comparée de <b>" + title_first_month  + "</b> à <b>" + title_last_month + "</b>",
                titlefont={'size':14},
                yaxis={'title': 'Puissance (kWh)'},
                showlegend=True,
                legend=go.layout.Legend(
                    x=0,
                    y=1.1,
                    orientation="h",
                    font={'size':10}),
                width=1000,
                height=350,
                margin={'l': 70, 'b': 70, 't': 70, 'r': 0, 'pad':20},
                hovermode='closest',
                clickmode='event'
                )
            
        }
    
    
    @app.callback(
    Output('graph-Comparison-Week', 'figure'),
    [Input('graph-Comparison-All-Weeks', 'clickData'),
     Input('data_points','children')])
    def update_graph_Week(week_selected, list_inv_selected):

        data=json.loads(list_inv_selected)
        list_inv_raw=json.loads(data['onduleur'])
        list_inv = [inv for inv in list_inv_raw if list_inv_raw[inv]==1]

        if week_selected is not None:
            fisrt_day = week_selected["points"][0]['x'][:10]
            last_day = datetime.datetime.strptime(fisrt_day, "%Y-%m-%d") + datetime.timedelta(days=7)
            #last_day = datetime.datetime.strptime(middle_day, "%Y-%m-%d") + datetime.timedelta(days=4) 
            
            title_last_day = datetime.datetime.strftime(last_day - datetime.timedelta(days=1), "%d %b") 
            title_first_day = datetime.datetime.strftime(datetime.datetime.strptime(fisrt_day, "%Y-%m-%d"), "%d %b %Y")
        else:
            fisrt_day = "2017-06-01"
            last_day = "2017-06-07"
            title_first_day = "1 Juin"
            title_last_day = "7 Juin 2017"
        
        list_data = []

        for inv in list_inv:
            temp_series = go.Scatter(
                                x = df_all_feat[fisrt_day:last_day].iloc[:,:8].resample("1D").sum().index,
                                y = df_all_feat[fisrt_day:last_day].iloc[:,:8].resample("1D").sum()[inv],
                                #text = day,
                                name = inv,
                                mode ='lines+markers',
                                line = dict(width = 2, color=(color[inv])),
                                marker = dict(size = 5)
                             )
            list_data.append(temp_series)

        return {
            'data': list_data,
            'layout': go.Layout(
                title="Semaine du <b>" + title_first_day  + "</b> au <b>" + title_last_day + "</b>",
                titlefont={'size':14},
                yaxis={'title': 'Puissance (kWh)', 'rangemode':'tozero'},
                showlegend=False,
                width=500,
                height=370,
                margin={'l': 70, 'b': 30, 't': 30, 'r': 0, 'pad':10},
                hovermode='closest'
                )
        }
    
    @app.callback(
    Output('graph-Comparison-Total-Production', 'figure'),
    [Input('slider-global', 'value'),
     Input('data_points','children')])
    def update_graph_Total_Production(range_date, list_inv_selected):


        data=json.loads(list_inv_selected)
        list_inv_raw=json.loads(data['onduleur'])
        list_inv = [inv for inv in list_inv_raw if list_inv_raw[inv]==1]
        list_inv.sort()
        
        list_inv_axis = [inv.replace("PVT0","").replace("INV0","") for inv in list_inv]
        
        list_color = [color[inv] for inv in list_inv]
        
        date_min = date_values[range_date[0]]
        date_max = date_values[range_date[1]]
        
        title_first_month = datetime.datetime.strftime(datetime.datetime.strptime(date_min, "%Y-%m"), "%b %y")
        title_last_month = datetime.datetime.strftime(datetime.datetime.strptime(date_max, "%Y-%m"), "%b %y")
        
        data = go.Bar(
                        x = list_inv_axis,
                        y = df_all_feat[date_min:date_max].loc[:,list_inv].sum(axis=0).sort_index(),
                        #text = day,
                        marker=dict(color=list_color)
                     )
        
        min_value = df_all_feat[date_min:date_max].loc[:,list_inv].sum(axis=0).sort_index().min()
        max_value = df_all_feat[date_min:date_max].loc[:,list_inv].sum(axis=0).sort_index().max()

        return {
            'data': [data],
            'layout': go.Layout(
                title="Production totale de <b>" + title_first_month  + "</b> à <b>" + title_last_month + "</b>",
                titlefont={'size':14},
                yaxis={'range':[min_value - 0.1*min_value, max_value + 0.02*max_value]},
                showlegend=False,
                width=350,
                height=370,
                margin={'l': 50, 'b': 30, 't': 30, 'r': 0, 'pad':10},
                hovermode='closest'
                )
        }