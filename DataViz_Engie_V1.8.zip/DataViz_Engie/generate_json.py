import datetime
import pandas as pd
import numpy as np
import json
import os


exit_file="All_Inverters.json"

def list_dates(start, end):
    delta = end - start
    listDates = []    
    for i in range(delta.days + 1):
        listDates = listDates + [str(start + datetime.timedelta(days=i))]
    
    return [listDates[i].split(' ')[0] for i in range(len(listDates))]

def generate_json(date_min="2017-06-01", date_max="2018-11-04"):

    path="./assets/data/"+exit_file

    if os.path.isfile(path):
        print("fichier déja existant")
        return

    inverters = ['PVT01_INV01','PVT01_INV02','PVT02_INV01','PVT02_INV02','PVT03_INV01','PVT03_INV02','PVT04_INV01','PVT04_INV02']    

    df_all_feat = pd.read_csv("./assets/data/All_features.csv", sep=",", index_col="DATE", parse_dates=True)

    start = datetime.datetime(int(date_min.split('-')[0]), int(date_min.split('-')[1]), int(date_min.split('-')[2]))
    end = datetime.datetime(int(date_max.split('-')[0]), int(date_max.split('-')[1]), int(date_max.split('-')[2]))

    df_ano = pd.read_csv("./assets/data/Anomalies_manuelles.csv", sep=",", index_col="Date", parse_dates=True)

    df_ano.fillna(value=0, inplace=True)
    df_ano.iloc[:,2:] = df_ano.iloc[:,2:].astype(np.int)

    #print(("{"))
    with open(path, 'a') as the_file:
        the_file.write("{")

    for inverter in inverters:        
        data_prod = []
        listDates = list_dates(start,end)
        for date in listDates:
            data_prod = data_prod + [np.array(df_all_feat[date][inverter].iloc[::6]).tolist()]            

        inverter = inverter.split('_')[0][-1] + '_' + inverter.split('_')[1][-1]

        #print("\""+ inverter +"\":")         
        #print("{\"meanTemp\": {")   
        with open(path, 'a') as the_file:
            the_file.write("\""+ inverter +"\":")

        with open(path, 'a') as the_file:
            the_file.write("{\"meanTemp\": {")

        for i in range(len(data_prod)):        
            d = dict({f"{''.join(listDates[i].split('-'))}": data_prod[i]})    
            if i == len(data_prod)-1:                  
                #print(json.dumps(d)[1:-1])
                with open(path, 'a') as the_file:
                    the_file.write(json.dumps(d)[1:-1])            
            else:
                #print(json.dumps(d)[1:-1]+',')
                with open(path, 'a') as the_file:
                    the_file.write(json.dumps(d)[1:-1]+',')                           

        #print("},\"info\": {")
        with open(path, 'a') as the_file:
                    the_file.write("},\"info\": {") 
        
        df_ano_f = df_ano.copy()
        df_ano_f = df_ano_f[df_ano_f['Ano'] == 1][date_min:date_max]
        df_ano_f = df_ano_f[df_ano_f[inverter]==1]
        df_ano_f = df_ano_f.loc[~df_ano_f.index.duplicated(keep='first')]

        columns = ['Type',inverter]

        #df_ano_f = df_ano_f.replace('Déconnexion','Deconnexion')
        df_ano_f = df_ano_f[columns]


        for j in range(df_ano_f[df_ano_f[inverter] == 1].shape[0]):   

            d = dict({''.join(str(df_ano_f[df_ano_f[inverter] == 1].index[j]).split(' ')[0].split('-')) : {'class': 'hot', 'text': f'<p style="color:red"> <b>Type d\'anomalie</b>: {df_ano_f[df_ano_f[inverter] == 1].iloc[j,0]}</p>'}})
            if j == df_ano_f[df_ano_f[inverter] == 1].shape[0]-1:
                #print(json.dumps(d)[1:-1])
                with open(path, 'a') as the_file:
                    the_file.write(json.dumps(d)[1:-1]) 
            else:
                #print(json.dumps(d)[1:-1]+',')
                with open(path, 'a') as the_file:
                    the_file.write(json.dumps(d)[1:-1]+',')

        with open(path, 'a') as the_file:
            the_file.write("}")

        #print("}")    
        if inverter in  '4_2': 
            with open(path, 'a') as the_file:
                the_file.write("}")
            #print("}")
        else:  
            with open(path, 'a') as the_file:
                the_file.write("},")
            #print("},")
    with open(path, 'a') as the_file:
        the_file.write("}")
    #print("}")
    print("fichier pret")
