import pandas as pd
import numpy as np
import colorsys


#data=pd.read_csv("./assets/data/event_corrected.csv",header=0,nrows=200)

df_all_feat = pd.read_csv("./assets/data/All_features.csv", sep=",", index_col="DATE", parse_dates=True)

df_ano = pd.read_csv("./assets/data/Anomalies_manuelles.csv", sep=",", index_col="Date", parse_dates=True)
df_ano.fillna(value=0, inplace=True)
df_ano.iloc[:,2:] = df_ano.iloc[:,2:].astype(np.int)

df_res_cum = pd.read_csv("./assets/data/All_Residus_cum_KNN.csv", index_col=[0], header=[0,1], parse_dates=True)

df_res = pd.read_csv("./assets/data/All_Residus_KNN.csv", index_col=[0], header=[0,1], parse_dates=True)

#df_res_clustering = pd.read_csv("./assets/data/residu_prem.csv", index_col=[0], header=[0,1], parse_dates=True)
df_res_clustering = pd.read_csv("./assets/data/residu_clustering_algo_025.csv", index_col=[0], header=[0,1], parse_dates=True)
inv_name=[col for col in df_all_feat.columns if ("PVT" in col) and ("INV" in col)]

df_clust_kmeans2 =  pd.read_csv("./assets/data/residu_clusterpca2.csv", index_col=[0], header=[0,1], parse_dates=True)
df_clust_kmeans10 =  pd.read_csv("./assets/data/residu_clusterpca10.csv", index_col=[0], header=[0,1], parse_dates=True)
df_clust_kmeans30 =  pd.read_csv("./assets/data/residu_clusterpca30.csv", index_col=[0], header=[0,1], parse_dates=True)

namea = ["Robust_covariance","Isolation_Forest"]

Z = {}
for inv in inv_name:
    for name in namea:
        f = inv + name
        df = pd.read_csv("./assets/data/" +str(f))
        Z[f] = df.iloc[:,1:]

def get_all_features():
    return df_all_feat

def get_anomalies():
    return df_ano

def get_res():
    return df_res

def get_res_cum():
    return df_res_cum

def get_clustering():
    return df_res_clustering

def get_kmeans2():
    return df_clust_kmeans2

def get_kmeans10():
    return df_clust_kmeans10

def get_kmeans30():
    return df_clust_kmeans30

def get_contour():
    return Z

def get_inv_unique():
    result=[{'label': 'selection', 'value': 'selection'}]
    carte_coords={'selection':[]}
    for case in inv_name:
        pvt=int(case[3:5])
        inv=int(case[-2:])
        result.append({'label': str(pvt)+"_"+str(inv), 'value': case})
        carte_coords[case]=[]
    return result,carte_coords

def gen_color():
    repartition={}
    for case in inv_name:
        inv = get_color_position(case)
        try:
            repartition[inv[0]].append(inv[1])
        except:
            repartition[inv[0]]=[inv[1]]
    cles=list(repartition.keys())
    n=len(cles)
    result={}
    #for x in range(n):
    #    step_y=0.8/len(repartition[cles[x]])
    #    for y in range(len(repartition[cles[x]])):
    #        m=len(repartition[cles[x]])
    #        hue = (x/n)- (.25/(2*n))+ ((y/m)*(.25/n))
    #        if hue<0:
    #            hue+=1
    #        color=colorsys.hsv_to_rgb(hue,1-(y*step_y),1-(y*step_y))
    #        txt="PVT"+cles[x]+"_INV"+repartition[cles[x]][y]
    #        result[txt]="rgb("+str(color[0]*255)+","+str(color[1]*255)+","+str(color[2]*255)+")"
            
    PVT01_INV01 = "166,206,227"
    PVT01_INV02 = "31,120,180"
    PVT02_INV01 = "253,191,111"
    PVT02_INV02 = "255,127,0"
    PVT03_INV01 = "178,223,138"
    PVT03_INV02 = "51,160,44"
    PVT04_INV01 = "251,154,153"
    PVT04_INV02 = "152,78,163"

    result = {'PVT01_INV01': 'rgb('+PVT01_INV01+')', 'PVT01_INV02': 'rgb('+PVT01_INV02+')', \
              'PVT02_INV01': 'rgb('+PVT02_INV01+')', 'PVT02_INV02': 'rgb('+PVT02_INV02+')', \
              'PVT03_INV01': 'rgb('+PVT03_INV01+')', 'PVT03_INV02': 'rgb('+PVT03_INV02+')', \
              'PVT04_INV01': 'rgb('+PVT04_INV01+')', 'PVT04_INV02': 'rgb('+PVT04_INV02+')'}
    return result

def get_color_position(txt):
    row = txt.split("_")
    return row[0][-2:],row[1][-2:]
