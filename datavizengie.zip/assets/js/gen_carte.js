
var inverter="";
var coords=[];

var mapsizew=532;
var mapsizeh=532;

widow_width=0;
widow_height=0;

function resize() {
    var target = document.getElementById('carte')
    sizew = target.offsetHeight*mapsizew/mapsizeh
    carte = d3.select('#carte')
        .style('width',sizew.toString().concat("","px"))

    widow_width=sizew;
    widow_height=target.offsetHeight;
    var target2 = document.getElementById('is_edited1');
    if (target2.classList[2]=="d-none"){

        draw_poligons();
    }else{
        draw_points();
    }
}

window.onresize = resize;







function change_bakground(txt) {
    if (txt=="oui"){
        carte = d3.select('#svgcarte')
            .style("background-image",'url(./assets/images/map.png)')
            .style('background-position','center')
            .style('background-repeat','no-repeat')
            .style('background-size','cover')


    }else {
        carte = d3.select('#svgcarte')
            .style("background-image", 'url()')
            .style('background-position', 'center')
            .style('background-repeat', 'no-repeat')
            .style('background-size', 'cover')
    }
};

function draw_points() {
    var data = document.getElementById("data_points").innerText.replace(/'/g, '"');
    data = JSON.parse(data);
    d3.select('#tooltip').attr('class','d-none')

    var rapport_x = widow_width / data['map_width'];
    var rapport_y = widow_height / data['map_height'];

    var polygon = d3.select('#carte_polygone').selectAll("polygon");
    polygon.data([]).exit().remove();

    var circle = d3.select('#carte_circle').selectAll("circle").data(data.carte_point);

    circle.exit().remove();

    circle.enter().append("circle")
        .attr("cx", function (d, i) {
            return d.x * rapport_x
        })
        .attr("cy", function (d, i) {
            return d.y * rapport_y
        })
        .attr("r", "4")
        .style("fill", "orange") // style from css
        .style("stroke", "orange")
        .style("fill-opacity", '0.5');

    circle.transition()
        .duration(500)
        .attr("cx", function (d, i) {
            return d.x * rapport_x
        })
        .attr("cy", function (d, i) {
            return d.y * rapport_y
        })
        .attr("r", "4")
        .style("stroke", "orange")
        .style("fill-opacity", '0.5');



}

function draw_poligons() {
    var data = document.getElementById("data_points").innerText;
    var color_rule=JSON.parse(document.getElementById('color_rule').innerText)

    data = JSON.parse(data);
    d3.select('#tooltip').attr('class','')
    if (widow_width==0){
        var target = document.getElementById('carte')
        sizew = target.offsetHeight*mapsizew/mapsizeh
        carte = d3.select('#carte')
            .style('width',sizew.toString().concat("","px"))

        widow_width=sizew;
        widow_height=target.offsetHeight;
    }

    var rapport_x = widow_width / data['map_width'];
    var rapport_y = widow_height / data['map_height'];
    //console.log(rapport_y)

    //console.log("draw polygon")

    var circle = d3.select('#carte_circle').selectAll("circle").data([]);
    circle.exit().remove();


    //console.log(data.key);
    data.key.forEach(function (item, index) {
        //console.log(item, index);
        //console.log(data[item]);
        var mouseover = function(d) {
            d3.select('#tooltip')
                .style("transition"," opacity 1s ease-in")
                .style("opacity", 1)
                .attr('class','')
        }
        var mousemove = function(d) {
            d3.select('#tooltip')
                .style("left", (d3.mouse(this)[0]-25) + "px")
                .style("top", (d3.mouse(this)[1]+15) + "px")
                //.style("background-color",color_rule[item])
            document.getElementById('tooltip').innerText="Zone ".concat(item.replace("PVT0","").replace("INV0",""))

        }
        var mouseleave = function(d) {
            d3.select('#tooltip')
                .style("transition"," opacity 0.1s ease-out")
                .style("opacity", 0)
                .attr('class','d-none');

        }
        var set_onduleur = function(d){
            var selection_type = document.getElementsByClassName('partie_comparaison')
            var data = document.getElementById("onduleur").innerText.replace(/'/g, '"');
            data = JSON.parse(data);
            if (selection_type[0].getAttribute('class').includes("d-none")){
                //console.log("pas comparaison")
                cle = Object.keys(data)
                for (key in cle){
                    if(cle[key]==item){
                        //console.log(item)
                        data[cle[key]]=1;
                        d3.select("#".concat(cle[key])).style("fill-opacity", '0.8')
                    }else{
                        data[cle[key]]=0;
                        d3.select("#".concat(cle[key])).style("fill-opacity", '0.4')
                    }
                }
            }else{
                if (data[item]==1){
                    data[item]=0;
                    d3.select("#".concat(item)).style("fill-opacity", '0.4')
                }
                else {
                    data[item]=1;
                    d3.select("#".concat(item)).style("fill-opacity", '0.8')
                }


            }

            document.getElementById("onduleur").innerText=JSON.stringify(data);

        }

        var polygon = d3.select('#carte_polygone').selectAll("#".concat(item));
        polygon.data([data[item]]).enter().append("polygon")
            .attr('id',item)
            .attr("points",function(d) {
                return d.map(function(d) { return [d.x* rapport_x,d.y* rapport_y].join(","); }).join(" ");})
            .attr("stroke",color_rule[item])
            .attr("stroke-width",2)
            .style("fill",color_rule[item])
            .on("mouseover", mouseover)
            .on("mousemove", mousemove)
            .on("mouseleave", mouseleave)
            .on("click",set_onduleur);



        polygon.data([data[item]]).transition()
            .duration(500)
            .attr('id',item)
            .attr("points",function(d) {
                return d.map(function(d) { return [d.x* rapport_x,d.y* rapport_y].join(","); }).join(" ");})
            .attr("stroke",color_rule[item])
            .attr("stroke-width",2);

        //console.log(data['onduleur'])
        try {
            var d2 = JSON.parse(data['onduleur'])
        }catch (e) {
            var d2 = data['onduleur']
        }
        //console.log(d2[item])
        if(d2[item]==1){
            d3.select("#".concat(item)).style("fill-opacity", '0.8')
        }else{
            d3.select("#".concat(item)).style("fill-opacity", '0.4')
        }

    });





}


function init() {
    var see_overview = function(){
        d3.selectAll("#overview").attr("class","nav-link active ");
        d3.selectAll("#performance").attr("class","nav-link ");
        d3.selectAll("#anomalie").attr("class","nav-link ");
        d3.selectAll(".partie_anomalie").attr("class","partie_anomalie d-none");
        d3.selectAll(".partie_comparaison").attr("class","partie_comparaison d-none");
        d3.selectAll(".partie_overview").attr("class","partie_overview");
        draw_poligons();
    }
    var see_perfomance = function(){
        d3.selectAll("#overview").attr("class","nav-link ");
        d3.selectAll("#performance").attr("class","nav-link active");
        d3.selectAll("#anomalie").attr("class","nav-link");
        d3.selectAll(".partie_anomalie").attr("class","partie_anomalie d-none");
        d3.selectAll(".partie_overview").attr("class","partie_overview d-none");
        d3.selectAll(".partie_comparaison").attr("class","partie_comparaison");
        draw_poligons();
    }
    var see_anomalie = function(){
        d3.selectAll("#overview").attr("class","nav-link ");
        d3.selectAll("#performance").attr("class","nav-link ");
        d3.selectAll("#anomalie").attr("class","nav-link active");
        d3.selectAll(".partie_comparaison").attr("class","partie_comparaison d-none");
        d3.selectAll(".partie_overview").attr("class","partie_overview d-none");
        d3.selectAll(".partie_anomalie").attr("class","partie_anomalie");
        draw_poligons();
    }
    
    d3.select("#menu").append("nav");

    var menu = d3.select("#menu").select("nav");

    menu.attr("class", "navbar navbar-expand-lg navbar-light bg-light");
    menu.append("button")
        .attr("class", "navbar-toggler")
        .attr("type", "button")
        .attr("data-toggle", "collapse")
        .attr("data-target", "#navbarNav")
        .attr("aria-controls", "navbarNav")
        .attr("aria-expanded", "false")
        .attr("aria-label", "Toggle navigation")
        .append('span')
        .attr("class", "navbar-toggler-icon");

    menu.append("div").attr("class", "collapse navbar-collapse").attr("id", "navbarNav")
        .append("ul").attr("class", "navbar-nav nav-pills");

    var menu_content = d3.select("#navbarNav").select("ul");

    menu_content.append("li").attr("class", "nav-item")
        .append("a").attr("class", "nav-link active").attr("id","overview")
        .on("click",see_overview)
        .html("Tour d'horizon");
    menu_content.append("li").attr("class", "nav-item")
        .append("a").attr("class", "nav-link").attr("id","performance")
        .on("click",see_perfomance)
        .html("Perfomances");
    menu_content.append("li").attr("class", "nav-item")
        .append("a").attr("class", "nav-link").attr("id","anomalie")
        .on("click",see_anomalie)
        .html("Anomalies");



}






