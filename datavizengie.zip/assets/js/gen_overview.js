var dataset;

var dict_month={"01":"janv",
    "02":"fevr",
    "03":"mars",
    "04":"avr",
    "05":"mai",
    "06":"jun",
    "07":"juill",
    "08":"aout",
    "09":"sept",
    "10":"oct",
    "11":"nov",
    "12":"dec"
}
function translate(x, y) {return 'translate('+x+','+y+')';}

function init_overview(){
    d3.json('./assets/data/All_Inverters.json', function(error, data){
        if (error) {
            console.log(error)
        } else {
            dataset = data;
        }
    });
    d3.select("#content_overview").append('p').attr("id","T1Z21_content")
    d3.select("#content_overview").append('div').attr("id","T1Z21_info")
    document.getElementById("T1Z21_content").innerHTML="<h3><p><strong>Production journalière</strong></p></h3>" +
    "Explorer la production journalière d'une ferme solaire pour une période de deux mois en bougeant le curseur de gauche " +
        "à droite apres avoir sélectionné un onduleur et une période. " +
    "Les jours en rouge sont des jours en anomalies"
    d3.select("#graphT1_Z12 svg").remove()
    d3.select("#graphT1_Z12").style("height","90vh")
        .append("svg")
            .attr('id',"svgoverview")
            .attr("width", "100%")
            .attr("height", "100%");
    d3.select("#slider_overview div .rc-slider-step").selectAll(".rc-slider-dot").on("click",update_slider())
}

window.onload = function(){
    init_overview()
};

//console.log(dataset);
function get_onduleur(onduleur){
    var selected_onduleur=""
    for ([key,value] of Object.entries(onduleur)){
        if(value==1){
            selected_onduleur+=key.toString().replace("PVT0","").replace("INV0","")
        }
    }

    return selected_onduleur
}


function draw_lines(tmp,start,end,name_inv){



    var data = tmp

    var xlen=0;
    var ylen=0
    var xwidth=600//document.getElementById('graphT1_Z12').offsetWidth-150;
    var yheight=document.getElementById('graphT1_Z12').offsetHeight;
    for ([key,value] of Object.entries(data["meanTemp"])){
        if(key<start || key > end){
            delete data["meanTemp"][key];
            delete data["info"][key];
        }
        else{
            xlen=value.length
            //xwidth-= 4
            ylen+=1

        }
    }
    //console.log(data["meanTemp"]);


    var xScale = d3.scaleLinear()
        .domain([0, xlen])
        .range([0, xwidth]);

    var yScale = d3.scaleLinear()
        .domain([-2,800])
        .range([150, 0]);


    var svgLine = d3.line()
        .curve(d3.curveCardinal)
        .x(function(d, i) {return xScale(i);})
        .y(function(d) {return yScale(d);});

    var hourscale = d3.scaleBand()
        .domain(['04:00', '05:00', '06:00', '07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00','16:00','17:00','18:00','19:00'])
        .rangeRound([0, xwidth]);

    var xAxis = d3.axisBottom(hourscale);

    var yAxis = d3.axisLeft(yScale)
        .tickValues([0, 100, 200, 300, 400, 500, 600, 700]);

    var ind=0
    d3.select("#svgoverview").selectAll(".overview_data").data([]).exit().remove();

    var date_dict = {};
    var colorScale = d3.scaleLinear()
        .domain([0, ylen])
        .range([1, 0.3]);
    for ([date,value] of Object.entries(data["meanTemp"])){
        date_dict[ind]=date;
        //console.log(value)
        var chart = d3.select("#svgoverview").selectAll("#_".concat(date.toString())).data([value]).enter().append('g')
            .attr('id',"_".concat(date.toString()))
            .attr('class','overview_data');


        opacite_text=0
        color="#333"
        anoclass=""
        if ( data['info'].hasOwnProperty(date)){
            opacite_text=1
            color="rgb(227,26,28)"
            anoclass="ano"
            //console.log(date)
        }
        chart.append('path')
            .attr('class', 'line')
            .attr('transform',translate(30+ind*4,250+yScale(0)-ind*6))
            .attr('d', function(d, i) {
                return svgLine(d);
            })
            .style('opacity', colorScale(ind))
            .style("stroke",color)
            .style("fill",function (d,i) {
                if (ind==0){
                    return"#DDD"
                }
                return "none"
            })
            .style("stroke-width",function (d,i) {
                if (ind==0){
                    return"4px"
                }
                return "1px"
            });
        content_txt=date.toString().slice(6,8)
        content_txt=content_txt.concat(" ")
        content_txt=content_txt.concat(dict_month[date.toString().slice(4,6)])
        content_txt=content_txt.concat(" ")
        content_txt=content_txt.concat(date.toString().slice(0,4))

        chart.append('text')
            .attr("class",anoclass)
            .attr("id","txt_".concat(date.toString()))
            .text(content_txt)
            .attr("transform",translate(30+xScale(xlen)+5+ind*4,250+150+yScale(0)-ind*6))
            .style("fill",color)
            .style("opacity",opacite_text);
        ind+=1
    }
    d3.select("#axisY").remove();
    d3.select("#axisX").remove();
    d3.select('#svgoverview ')
        .append('g')
        .attr("id","axisY")
        .attr("font-weight","300")
        .style("font-size", "13px")
        .attr("fill","#666")
        .attr('transform', translate(30+0, 250+yScale(0)))
        .call(yAxis);

    d3.select('#svgoverview ')
        .append('g')
        .attr("id","axisX")
        .attr("font-weight","300")
        .style("font-size", "13px")
        .attr("fill","#666")
        .attr('transform', translate(30+0, 250+150+yScale(0)))
        .call(xAxis);


    var indexScale=d3.scaleLinear()
        .domain([0,document.getElementById('graphT1_Z12').offsetWidth])
        .range([0,ylen-1]);

    var mosemoove = function(){
        coords = d3.mouse(this)
        var index_ref=Math.round(indexScale(coords[0]))
        var id_ref = date_dict[index_ref]
        var colorScale = d3.scaleLinear()
            .domain([index_ref, ylen])
            .range([1, 0.3]);

        for ([index,id] of Object.entries(date_dict)){

            d3.selectAll("#_".concat(id.toString()).concat(" text")).style("opacity",0)
            if (id_ref < id){
                d3.selectAll("#_".concat(id.toString()).concat(" path")).style("opacity",colorScale(index))
                    .style("stroke-width","1px")
                    .style("fill","none");
                d3.selectAll("#_".concat(id.toString()).concat(" .ano")).style("opacity",1)
            }
            else{

                if (id_ref == id){
                    d3.selectAll("#_".concat(id.toString()).concat(" path")).style("opacity",1)
                        .style("stroke-width","4px")
                        .style("fill","#DDD");
                    d3.select("#axisY").attr('transform', translate(30+index*4, 250+yScale(0)-index*6));
                    d3.select("#axisX").attr('transform', translate(30+index*4, 250+150+yScale(0)-index*6));
                    d3.selectAll("#_".concat(id.toString()).concat(" text")).style("opacity",1)

                    var sum = Math.round(data["meanTemp"][id].reduce((previous, current) => current += previous));
                    var avg = Math.round(sum / data["meanTemp"][id].length);
                    var max = Math.round(Math.max(...data["meanTemp"][id]));
                    var content=""
                    if ( data['info'].hasOwnProperty(id)){
                       content+=data['info'][id]['text']
                    }

                    var content_txt=id.toString().slice(6,8)
                    content_txt=content_txt.concat(" ")
                    content_txt=content_txt.concat(dict_month[id.toString().slice(4,6)])
                    content_txt=content_txt.concat(" ")
                    content_txt=content_txt.concat(id.toString().slice(0,4))
                    var html ="<h3>".concat(content_txt," - <strong> Zone: ",name_inv.toString(), "</strong>").concat("</h3><b>Puissance totale:</b> ")
                    html+=sum.toString() + ' kWh'
                    html+="<br/><b>Puissance maximum:</b> "
                    html+=max.toString() + ' kWh'
                    html+="<br/><b>Puissance moyenne:</b> "
                    html+=avg.toString() + ' kWh'
                    html+="<br/>"
                    html+=content

                    document.getElementById("T1Z21_info").innerHTML=html
                }else{
                    d3.selectAll("#_".concat(id.toString()).concat(" path")).style("opacity",0)
                }
            }

        }
        //console.log(index_ref)
    }
    d3.select("#svgoverview").on("mousemove",mosemoove)




}

function update_selected_overview(){
    var data = JSON.parse(document.getElementById("data_points").innerText)
    var onduleur=JSON.parse(data['onduleur'])

    var start_date=data['start_date']
    var end_date = data['end_date']
    onduleur=get_onduleur(onduleur)
    draw_lines(dataset[onduleur],start_date,end_date,onduleur)



}



function update_slider(){
    // rc-slider-dot-active
    var active = 0;
    var start =0
    var width =0
    d3.selectAll(".overview_bullet").remove()
    d3.select("#slider_overview div .rc-slider-step").selectAll(".rc-slider-dot")
        .each(function (d,i) {
            //console.log(d)
            if (active==1){
                width=parseFloat(d3.select(this).attr("style").replace("left:","").replace("%;",""))-start

                d3.select(this).append("div")
                    .attr("class","overview_bullet rc-slider-handle")
            }if (active>0){active-=1;}
            if (d3.select(this).attr("class").includes("rc-slider-dot-active")){
                active=2
                start=parseFloat(d3.select(this).attr("style").replace("left:","").replace("%;",""))
            }
        })
    var txt_left="".concat(start.toString()).concat("%")
    var txt_width="".concat(width.toString()).concat("%")
    d3.select("#slider_overview div .rc-slider-track")
        .style("left",txt_left)
        .style("width",txt_width)
        .style("visibility","visible")
    //console.log(txt_left)
    //console.log(txt_width)
}

