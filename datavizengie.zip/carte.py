import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output,State
import initialisation as init
import pandas as pd
import visdcc
import json
import datetime
import locale
locale.setlocale(locale.LC_ALL,'')


min_date = datetime.datetime.strptime("2017-06-01", "%Y-%m-%d")
datelist=pd.date_range(min_date, periods=19, freq='MS')

mark_month={} # dict des markers de mois abrégés "Apr', "May', etc
date_values={} #dict des valeurs correspondantes aux markers
m=1
for i in datelist:
    if i.year==2017 and i.month==6:
        mark_month[m] = {'label':i.strftime('%b') + " 2017",  'style': {'z-index': '5'} }
    elif i.year==2018 and i.month==1:
        mark_month[m] = {'label':i.strftime('%b') + " 2018",  'style': {'z-index': '5'} }
    else:
        mark_month[m] = {'label':i.strftime('%b'),  'style': {'z-index': '5'} }
    date_values[m]=str(i.year)+"-"+str(i.month)
    m+=1


def get_content():
    return html.Div([
        html.Div(children=[
            dcc.Slider(
                id="slider_overview",
                min=1,
                max=19,
                value=1,
                marks=mark_month,
                included=False
            )], style={'width':'95%', 'display': 'inline-block',"top":"-45px","position":"absolute"}),
        html.Div(id="graphT1_Z12",style={"height":"90vh"})
    ])

def getcarte(inv_option):
    selected={}
    selected[inv_option[1]["value"]]=1
    for inv in inv_option[2:]:
        selected[inv["value"]]=0
    #print(selected)

    return [html.Div(className='overflow-auto',children=[
        html.Div(style={'height':'35vh','margin':'0px auto'},id='carte'),
    ]),
    html.Div(style={'height':'10vh'},children=[
        html.Div(className='d-none',id='data_points'),
        html.Div(className='d-none',id='onduleur',children=[
            json.dumps(selected)
        ]),
        html.Div(className="row",children=[
            html.Div(className="col-md-2 text-center",children=[
                html.Button(className='btn btn-primary',id="show_map",children=[html.I(className="fas fa-map-marked-alt")]),
            ]),
            html.Div(className="col-md-2 text-center",children=[
                html.Button(className='btn btn-primary',id="edit_point",children=[html.I(className="far fa-edit")]),
            ]),
            html.Div(className="col-md-6 text-center",id="is_edited1",children=[
                dcc.Dropdown(
                    id='carte_inv_choice',
                    options=inv_option,
                    value='selection'
                ),
            ]),
            html.Div(className="col-md-2 text-center",id="is_edited2",children=[
                html.Button(className='btn btn-primary',id="save",children=[html.I(className="far fa-save")]),]),


        ])
    ])]


def carte_callbacks(app,carte_coords):
    for i in range(1,3):
        out=str('is_edited'+str(i))
        #print(out)
        @app.callback(output=Output(out,'className'),
                      inputs=[Input('edit_point','n_clicks')],
                      state=[State(out,'className')])
        def is_edit(n_clicks,classs):
            classs=classs.split(" ")[0]
            #print(classs)
            try:
                if n_clicks%2==0 :
                    return classs+' text-center d-none'
                return classs+' text-center'
            except:
                return classs+' text-center d-none'



    @app.callback(output=Output('show_map','className'),
                  inputs=[Input('show_map','n_clicks')])
    def change_button(n_clicks):
        try:
            if n_clicks%2==1 :
                return 'btn btn-primary'
            return 'btn btn-success'
        except:
            return 'btn btn-success'


    @app.callback(
        Output('javascript', 'run'),
        [Input('show_map', 'n_clicks')])
    def alert(n_clicks):
        try:
            if n_clicks%2==0 :
                return 'change_bakground("oui")'
            else:
                return 'change_bakground("non")'
        except:
            #print('init')

            try:
                with open('data_points.json') as json_file:
                    test = json.load(json_file)
                for cle in test.keys():
                    carte_coords.update({cle:test[cle]})
            except:
                print('pas de fichier')
            #print(carte_coords)

            return '''var target = document.getElementById('carte')
            //console.log(target.offsetWidth);
            d3.select("#carte")
            .append("div")
            .attr('id','tooltip')
            .style("position", "absolute")
            .style("opacity", "0")
            .style("background-color", "#E0E0E0")
            .style("border", "solid")
            .style("border-width", "2px")
            .style("border-radius", "5px")
            .style("width", "90px")
            .style("height", "40px")
            .style("padding", "5px")
            
            d3.select('#carte')
            .append('svg')
            .attr('id','svgcarte')
            .style('width',"100%")
            .style('height',"100%")
            .on('click', function() {
                coords = d3.mouse(this);
                var data = JSON.parse(document.getElementById('onduleur').innerText.toString())
                //console.log(data);
                setProps({ 
                'event': {'carte_x':coords[0], 
                          'carte_y':coords[1],
                          'widow_width':target.offsetWidth,
                          'widow_height':target.offsetHeight,
                          'onduleur':JSON.stringify(data)
                          }
                })
                //console.log(this)
            })
            .append('g')
            .attr('id',"carte_circle");
            
            d3.select('#carte').select('svg')
                .append('g')
                .attr('id',"carte_polygone");
            
            change_bakground("oui");
                
          
            
            
        
        '''


    @app.callback(
        Output('data_points', 'className'),
        [Input('carte_inv_choice', 'value')])
    def myfun(inv_choice):
        carte_coords['carte_point']=[]
        carte_coords[inv_choice]=[]
        return 'd-none'

    @app.callback(
        Output('javascript2', 'run'),
        [Input('data_points', 'children'),
         Input('edit_point','n_clicks')])
    def myfun(data,nclicks):
        try:
            if nclicks%2==0:
                #print('visu')
                return 'draw_poligons()'
            else:
                #print('edition')
                return 'draw_points()'
        except:
            return '''draw_poligons();
            init_overview();
            update_selected_overview();'''
        return 'draw_poligons()'

    def get_date(date_txt):
        date=[int(x) for x in date_values[date_txt].split("-")]
        month=str(date[1])
        if len(month)<2:
            month="0"+month

        datestart=str(date[0])+month+"01"
        if date[1]+2>12:
            date[0]+=1
            date[1]=(date[1]+2)%11
            date[1]-=1
        else:
            date[1]+=2

        month=str(date[1])
        if len(month)<2:
            month="0"+month
        dateend=str(date[0])+month+"01"
        return datestart,dateend


    @app.callback(
        Output('data_points', 'children'),
        [Input('javascript', 'event'),
         Input("slider_overview","value")],
        [State('carte_inv_choice','value'),
         State('edit_point','n_clicks')])
    def myfun(x,datestart,inv_choice,nclicks):
        try:
            date_range = get_date(datestart)
            carte_coords['start_date']=date_range[0]
            carte_coords['end_date']=date_range[1]
            carte_coords.update({'onduleur':x['onduleur']})
            if x['widow_height']!=carte_coords['widow_height']:
                carte_coords.update({'widow_height':x['widow_height']})
                #print('image height')
            if x['widow_width']!=carte_coords['widow_width']:
                #print('image width')
                carte_coords.update({'widow_width':x['widow_width']})
            if nclicks%2==1:
                rapport_x=carte_coords['map_width']/carte_coords['widow_width']
                rapport_y=carte_coords['map_height']/carte_coords['widow_height']
                carte_x=x['carte_x']*rapport_x
                carte_y=(x['carte_y'])*rapport_y
                carte_coords['carte_point'].append({'x':carte_x,'y':carte_y})
                carte_coords.update({inv_choice:carte_coords['carte_point']})
                carte_coords['selection']=[]
                #carte_coords.update({'carte_point':carte_coords[inv_choice]})

        except:
            return json.dumps(carte_coords)
        return json.dumps(carte_coords)







    def update_data_saved(inv_choice):
        data_point={}
        try:
            with open('data_points.json') as json_file:
                data_point = json.load(json_file)

        except:
            print("fichier non lu ou pas de col selection")
        data_point[inv_choice]=carte_coords[inv_choice]
        key=list(data_point.keys())
        try:
            key.remove('selection')
        except:
            print(key)
        key.sort()
        carte_coords["key"]=key
        carte_coords['selection']=[]

        try:
            with open('data_points.json', 'w') as outfile:
                json.dump(data_point, outfile,sort_keys=True, indent=4)
        except:
            print("fichier non ecrit")
            return 'btn btn-danger'
        return 'btn btn-success'

    @app.callback(
        Output('save', 'className'),
        [Input('save', 'n_clicks'),
         Input('edit_point','n_clicks'),
         Input('carte_inv_choice','value')])
    def data_point_generation(save_clicks,edit_clicks,inv_choice):
        try:
            if int(edit_clicks)%2==1:
                if int(save_clicks) > carte_coords['sv_click']:
                    #print(carte_coords)
                    carte_coords['sv_click']=int(save_clicks)
                    #print('enregistrement')
                    return update_data_saved(inv_choice)
        except Exception as e:
            #print('erreur', e)
            return 'btn btn-primary'
        return 'btn btn-primary'