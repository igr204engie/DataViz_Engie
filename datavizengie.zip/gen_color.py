import colorsys

n=8
step=360/n
#print(step)
hue=[(x*step) for x in range(n)]
#print(hue)

HSV_tuples = [(x*1.0/5, 1, 1) for x in range(n)]
RGB_tuples = map(lambda x: colorsys.hsv_to_rgb(*x), HSV_tuples)
#print(list(RGB_tuples))