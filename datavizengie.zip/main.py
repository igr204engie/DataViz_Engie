import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output,State
import initialisation as init
import pandas as pd
import visdcc
import json
from carte import *
from Comparaison import *
from Anomalies import *
from overview import *
from generate_json import *
import locale
locale.setlocale(locale.LC_ALL,'')

inv_option,carte_coords=init.get_inv_unique()
#df_all_feat = init.get_all_features()

color=init.gen_color()

selected={}
selected[inv_option[1]["value"]]=1
for inv in inv_option[2:]:
    selected[inv["value"]]=0
try:
    with open('data_points.json') as json_file:
        carte_coords = json.load(json_file)

except:
    print('pas de fichier')
    
key=list(carte_coords.keys())
try:
    key.remove('selection')
except:
    print(key)
key.sort()
carte_coords["key"]=key
widow_height=0
widow_width=0
map_height=532
map_width=532
carte_coords.update({'widow_height':widow_height})
carte_coords.update({'widow_width':widow_width})
carte_coords.update({'map_height':map_height})
carte_coords.update({'map_width':map_width})
carte_coords['carte_point']=[]
carte_coords.update({'onduleur':json.dumps(selected)})

carte_coords['ed_click']=0
carte_coords['sv_click']=0
carte_coords['start_date']=20170601
carte_coords['end_date']=20170801



external_scripts = [
    {'src': 'assets/js/d3.v4.min.js'},
    {'src': 'assets/js/jquery-3.3.1.min.js'},
    {'src': 'assets/js/bootstrap.bundle.min.js'},
    {'src': 'assets/js/all.js'}
]

external_stylesheets = [
    {'rel':'stylesheet', 'href':'/assets/css/bootstrap.min.css'}

]

app = dash.Dash(__name__,
                external_scripts=external_scripts,
                external_stylesheets=external_stylesheets)
app.config['suppress_callback_exceptions']=True
app.config['locale'] = 'fr'

app.scripts.append_script({"external_url": "assets/js/plotly-locale-fr-latest.js"})


app.layout = html.Div(children=[
    html.Div(id="menu"),
    html.Div(id="color_rule",className='d-none',children=json.dumps(color)),

    html.Div(className="row",style={"margin-right":"0px !important"},children=[
       html.Div(className="col-md-3",children=[
           html.Div(className="",style={'height':'45vh','padding':'5px'},children=getcarte(inv_option)),
           html.Div(className="",style={'height':'45vh'},children=[
               html.Div(className="partie_overview", style={'padding':'5px'},children=[
                   html.Div(id="content_overview")
               ]),
               html.Div(className="partie_comparaison  d-none",style={'padding':'5px'}, children=[
                   html.Div(className="", children=getComparaisonTotalProduction())
               ]),
               html.Div(className="partie_anomalie  d-none",style={'padding':'5px'}, children=[
                   html.Div(className="", children=[getAnomaliesPerType()])
               ])
           ])
       ]),
       html.Div(className="col-md-9",children=[
           html.Div(id="check_overview",className="partie_overview",style={'padding':'5px'}, children=[
               get_content()
           ]),
           html.Div(className="partie_comparaison  d-none",style={'padding':'5px'}, children=[
               html.Div(children=[getComparaisonGlobal()]),
               html.Div(className="row",style={'height':'45vh'},children=[
                   html.Div(className="col-md-6",children=[
                       html.Div(className="", children=[getComparaisonWeek()])

                   ]),
                   html.Div(className="col-md-6",children=[
                       html.Div(className="", children=[getComparaisonDay()])
                   ])
               ]),
           ]),
           html.Div(className="partie_anomalie  d-none",style={'padding':'5px'}, children=[
               html.Div(className="",style={'height':'45vh'},children=[
                   html.Div(id="T3_list_inv_selected", style={'display': 'none'}),
                   html.Div(className="", children=[getAnomaliesGlobal()])
               ]),
               html.Div(className="row",style={'height':'45vh'},children=[
                   html.Div(className="col-md-6",children=[
                       html.Div(className="", children=[getClusteringDay()])
                   ]),
                   html.Div(className="col-md-6",children=[
                       html.Div(className="", children=[getAnomaliesDay()])
                   ])
               ]),
           ])
       ])
    ]),


    html.Script(src= './assets/js/gen_overview.js',type="text/javascript"),
    html.Script(src= './assets/js/gen_carte.js',type="text/javascript"),
    visdcc.Run_js(id = 'javascript',run="init()"),
    visdcc.Run_js(id = 'javascript2',run="Plotly.setPlotConfig({locale: \'fr\'})"),
    visdcc.Run_js(id = 'javascript3'),
    visdcc.Run_js(id = 'javascript4')


])




carte_callbacks(app,carte_coords)
comparaison_callbacks(app,carte_coords)
anomalies_callbacks(app,carte_coords)
overview_callbacks(app,carte_coords)


if __name__ == '__main__':
    generate_json()
    app.run_server(debug=True, port=8051)