
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output,State
import json
import locale
locale.setlocale(locale.LC_ALL,'')


def overview_callbacks(app,carte_coords):
    @app.callback(
        Output('javascript3', 'run'),
        [Input('data_points', 'children')])
    def lauch(data,):
        data=json.loads(data)
        list_inv_raw=json.loads(data['onduleur'])
        list_inv = [inv for inv in list_inv_raw if list_inv_raw[inv] == 1]
        if len(list_inv)<2:
            return 'update_selected_overview()'
        return ''

    @app.callback(
        Output('javascript4', 'run'),
        [Input('slider_overview', 'value')])
    def lauch(data,):

        return 'update_slider()'